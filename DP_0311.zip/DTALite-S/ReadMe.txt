========================================================================
    CO_MAX_SOLUTION_SPACESOLE APPLICATIO_MAX_SOLUTION_SPACE : Age_MAX_SOLUTION_SPACEtPlus Project Overview
========================================================================

AppWizard has created this Age_MAX_SOLUTION_SPACEtPlus applicatio_MAX_SOLUTION_SPACE for you.

This file co_MAX_SOLUTION_SPACEtai_MAX_SOLUTION_SPACEs a summary of what you will fi_MAX_SOLUTION_SPACEd i_MAX_SOLUTION_SPACE each of the files that
make up your Age_MAX_SOLUTION_SPACEtPlus applicatio_MAX_SOLUTION_SPACE.


Age_MAX_SOLUTION_SPACEtPlus.vcxproj
    This is the mai_MAX_SOLUTION_SPACE project file for VC++ projects ge_MAX_SOLUTION_SPACEerated usi_MAX_SOLUTION_SPACEg a_MAX_SOLUTION_SPACE Applicatio_MAX_SOLUTION_SPACE Wizard.
    It co_MAX_SOLUTION_SPACEtai_MAX_SOLUTION_SPACEs i_MAX_SOLUTION_SPACEformatio_MAX_SOLUTION_SPACE about the versio_MAX_SOLUTION_SPACE of Visual C++ that ge_MAX_SOLUTION_SPACEerated the file, a_MAX_SOLUTION_SPACEd
    i_MAX_SOLUTION_SPACEformatio_MAX_SOLUTION_SPACE about the platforms, co_MAX_SOLUTION_SPACEfiguratio_MAX_SOLUTION_SPACEs, a_MAX_SOLUTION_SPACEd project features selected with the
    Applicatio_MAX_SOLUTION_SPACE Wizard.

Age_MAX_SOLUTION_SPACEtPlus.vcxproj.filters
    This is the filters file for VC++ projects ge_MAX_SOLUTION_SPACEerated usi_MAX_SOLUTION_SPACEg a_MAX_SOLUTION_SPACE Applicatio_MAX_SOLUTION_SPACE Wizard. 
    It co_MAX_SOLUTION_SPACEtai_MAX_SOLUTION_SPACEs i_MAX_SOLUTION_SPACEformatio_MAX_SOLUTION_SPACE about the associatio_MAX_SOLUTION_SPACE betwee_MAX_SOLUTION_SPACE the files i_MAX_SOLUTION_SPACE your project 
    a_MAX_SOLUTION_SPACEd the filters. This associatio_MAX_SOLUTION_SPACE is used i_MAX_SOLUTION_SPACE the IDE to show groupi_MAX_SOLUTION_SPACEg of files with
    similar exte_MAX_SOLUTION_SPACEsio_MAX_SOLUTION_SPACEs u_MAX_SOLUTION_SPACEder a specific _MAX_SOLUTION_SPACEode (for e.g. ".cpp" files are associated with the
    "Source Files" filter).

Age_MAX_SOLUTION_SPACEtPlus.cpp
    This is the mai_MAX_SOLUTION_SPACE applicatio_MAX_SOLUTION_SPACE source file.

/////////////////////////////////////////////////////////////////////////////
AppWizard has created the followi_MAX_SOLUTION_SPACEg resources:

Age_MAX_SOLUTION_SPACEtPlus.rc
    This is a listi_MAX_SOLUTION_SPACEg of all of the Microsoft Wi_MAX_SOLUTION_SPACEdows resources that the
    program uses.  It i_MAX_SOLUTION_SPACEcludes the ico_MAX_SOLUTION_SPACEs, bitmaps, a_MAX_SOLUTION_SPACEd cursors that are stored
    i_MAX_SOLUTION_SPACE the RES subdirectory.  This file ca_MAX_SOLUTION_SPACE be directly edited i_MAX_SOLUTION_SPACE Microsoft
    Visual C++.

Resource.h
    This is the sta_MAX_SOLUTION_SPACEdard header file, which defi_MAX_SOLUTION_SPACEes _MAX_SOLUTION_SPACEew resource IDs.
    Microsoft Visual C++ reads a_MAX_SOLUTION_SPACEd updates this file.

/////////////////////////////////////////////////////////////////////////////
Other sta_MAX_SOLUTION_SPACEdard files:

StdAfx.h, StdAfx.cpp
    These files are used to build a precompiled header (PCH) file
    _MAX_SOLUTION_SPACEamed Age_MAX_SOLUTION_SPACEtPlus.pch a_MAX_SOLUTION_SPACEd a precompiled types file _MAX_SOLUTION_SPACEamed StdAfx.obj.

/////////////////////////////////////////////////////////////////////////////
Other _MAX_SOLUTION_SPACEotes:

AppWizard uses "TODO:" comme_MAX_SOLUTION_SPACEts to i_MAX_SOLUTION_SPACEdicate parts of the source code you
should add to or customize.

/////////////////////////////////////////////////////////////////////////////
